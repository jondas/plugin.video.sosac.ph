# -*- coding: UTF-8 -*-
#/*
# *      Copyright (C) 2013 Libor Zoubek
# *
# *
# *  This Program is free software; you can redistribute it and/or modify
# *  it under the terms of the GNU General Public License as published by
# *  the Free Software Foundation; either version 2, or (at your option)
# *  any later version.
# *
# *  This Program is distributed in the hope that it will be useful,
# *  but WITHOUT ANY WARRANTY; without even the implied warranty of
# *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
# *  GNU General Public License for more details.
# *
# *  You should have received a copy of the GNU General Public License
# *  along with this program; see the file COPYING.  If not, write to
# *  the Free Software Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.
# *  http://www.gnu.org/copyleft/gpl.html
# *
# */

import re,os,urllib,urllib2,cookielib
import util

from provider import ContentProvider,cached,ResolveException


class TVSosacContentProvider(ContentProvider):

    def __init__(self,username=None,password=None,filter=None,reverse_eps=False):
        ContentProvider.__init__(self,'movies.sosac.ph','http://movies.sosac.ph/',username,password,filter)
        opener = urllib2.build_opener(urllib2.HTTPCookieProcessor(cookielib.LWPCookieJar()))
        urllib2.install_opener(opener)
        self.reverse_eps = reverse_eps

    def capabilities(self):
        return ['resolve','categories']

    def categories(self):
        result = []
        for i in ['0-9','a','b','c','d','e','f','g','e','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z']:
            item = self.dir_item()
            item['title'] = i.upper()
            item['url'] = 'cs/movies-a-z/' + i
            result.append(item)
        return result

    @staticmethod
    def remove_flag_from_url(url, flag):
        return url.replace(flag, "", count=1)

    def list(self,url):
        if url.find('movies-a-z') >= 0:
            return self.list_movies_by_letter(url)

    @cached(ttl=24*6)
    def list_movies_by_letter(self, url):
        """
        :param url: unknown
        :return:  list of movies that start from particular letter
        """
        result = []
        page = util.request(self._url(url))
        data = util.substr(page,'<ul class=\"content','</ul>') 
        for m in re.finditer('<a class=\"title\" href=\"(?P<url>[^\"]+)[^>]+>(?P<name>[^<]+)',data,re.IGNORECASE | re.DOTALL):
            item = self.movie_item() #mark item as movie
            item['url'] = m.group('url')
            item['title'] = m.group('name')
            self._filter(result,item)
        paging = util.substr(page,'<div class=\"pagination\"','</div')
        next = re.search('<li class=\"next[^<]+<a href=\"\?page=(?P<page>\d+)',paging,re.IGNORECASE | re.DOTALL)
        if next:
            next_page = int(next.group('page'))
            current = re.search('\?page=(?P<page>\d)',url)
            current_page = 0
            if current:
                current_page = int(current.group('page'))
            if current_page < next_page:
                url = re.sub('\?.+?$','',url) + '?page='+str(next_page)
                result += self.list_movies_by_letter(url)
        return result

    def resolve(self,item,captcha_cb=None,select_cb=None):
        page = util.request(item['url'])
        data = util.substr(page,'<div class=\"bottom-player\"','div>')
        if data.find('<iframe') < 0:
            raise ResolveException('Movie is not yet available.')
        result = self.findstreams(data,['<iframe src=\"(?P<url>[^\"]+)'])
        if len(result)==1:
            return result[0]
        elif len(result) > 1 and select_cb:
            return select_cb(result)
